# Kinematic character 2D project starter

Used by the "Kinematic character (2D)" tutorial:

https://docs.godotengine.org/en/latest/tutorials/physics/kinematic_character_2d.html
